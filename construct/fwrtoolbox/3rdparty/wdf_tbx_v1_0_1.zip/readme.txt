For details see
http://ens.ewi.tudelft.nl/~huib/mtbx
and particularly the User's Guide and the Reference Guide 
on the Downloads page.
