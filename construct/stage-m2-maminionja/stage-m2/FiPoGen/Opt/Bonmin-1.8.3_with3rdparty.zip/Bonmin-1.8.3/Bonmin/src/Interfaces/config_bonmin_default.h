
/***************************************************************************/
/*           HERE DEFINE THE PROJECT SPECIFIC PUBLIC MACROS                */
/*    These are only in effect in a setting that doesn't use configure     */
/***************************************************************************/

/* Version number of project */
#define BONMIN_VERSION "1.8.3"

/* Major Version number of project */
#define BONMIN_VERSION_MAJOR 1

/* Minor Version number of project */
#define BONMIN_VERSION_MINOR 8

/* Release Version number of project */
#define BONMIN_VERSION_RELEASE 3
