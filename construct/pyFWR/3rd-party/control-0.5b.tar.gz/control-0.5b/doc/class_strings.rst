Python-Control Classes
********************** 

State Space Class
=================
.. automodule:: statesp
   :members:

Transfer Function Class
=======================
.. automodule:: xferfcn
   :members:
