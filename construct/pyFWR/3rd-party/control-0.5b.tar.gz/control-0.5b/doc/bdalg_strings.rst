Block Diagram Algebra
*********************

.. toctree::

.. automodule:: bdalg
   :members:
