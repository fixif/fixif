Frequency Domain Plotting
*************************

.. toctree::

Plotting routines
=================
.. autofunction:: freqplot.bode_plot
.. autofunction:: freqplot.nyquist_plot
.. autofunction:: freqplot.gangof4_plot
.. autofunction:: nichols.nichols_plot

Utility functions
=================
.. autofunction:: freqplot.default_frequency_range
