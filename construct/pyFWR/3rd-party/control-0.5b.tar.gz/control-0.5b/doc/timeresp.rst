Time Domain Simulation
**********************

.. automodule:: timeresp
    :members:

.. autofunction:: phaseplot.phase_plot
.. autofunction:: phaseplot.box_grid
