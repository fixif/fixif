Model Simplification Tools
**************************

.. automodule:: modelsimp
    :members:
