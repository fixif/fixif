                Digital Signal Processing Library
                ---------------------------------
                                 by Matthias Hotz


This library is an extension of the example of Karlheinz Ochs [1] and
provides basic building blocks for block diagrams and signal flow graphs.

The library has to be installed. For example, in MiKTeX you can open
the MiKTeX Options dialog, go to the tab "Roots" and add the folder which
contains the "tex" folder found in this archive under "library" as a root
path.

[1] http://www.texample.net/tikz/examples/signal-flow-building-blocks/
