function [ nDeltay ] = NOE( R )
%UNTITLED Summary of this function goes here
%   Detailed explanation goes here

% centered Normalized Output error

% fonction de transfert Hu et He
Hu = ss( R.AZ, R.BZ, [inv(R.J)*R.M;R.AZ;R.CZ], [inv(R.J)*R.N; R.BZ; R.DZ], -1 );
He = ss(R.AZ, [ R.K*inv(R.J) eye(R.n) zeros(R.n,R.m) ], R.CZ, [ R.L*inv(R.J) zeros(R.p,R.n) eye(R.p) ],-1);



%DC-Gain and WCPG (Hu / he)
[dcHe wcpgHe] = dc_norminf(He);
[dcHu wcpgHu] = dc_norminf(Hu);


nDeltay = wcpgHe * 2.^floor(log2(wcpgHu)) ;

end


function [dc, b] = dc_norminf(H)
dc = dcgain(H);
[Yimp Timp] = impulse(H,1e5);
b = squeeze(sum(abs(Yimp)))';
end


