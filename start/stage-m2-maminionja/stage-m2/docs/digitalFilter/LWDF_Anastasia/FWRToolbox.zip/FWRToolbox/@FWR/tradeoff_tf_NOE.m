function v = tradeoff_tf_NOE (R, ETF, ENOE)

v = error_tf(R)/ETF + NOE(R)/ENOE;

